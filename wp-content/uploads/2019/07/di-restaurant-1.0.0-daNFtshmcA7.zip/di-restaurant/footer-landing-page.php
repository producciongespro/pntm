</div>

<?php get_template_part( 'template-parts/footer', 'backtotop' ); ?>

<?php wp_footer(); ?>
</body>
</html>
