<!-- Loader icon -->
<?php
if( get_theme_mod( 'loading_icon', '0' ) == '1' ) {
?>
	<div class="load-icon"></div>
<?php
}
?>
<!-- Loader icon Ends -->