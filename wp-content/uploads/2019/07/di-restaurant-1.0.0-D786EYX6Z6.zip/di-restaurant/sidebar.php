<div class="col-md-4">
	<div class="right-main-container">
		<?php
		if( is_active_sidebar( 'sidebar-1' ) ) {
			dynamic_sidebar( 'sidebar-1' );
		}
		?>
	</div>
</div>
