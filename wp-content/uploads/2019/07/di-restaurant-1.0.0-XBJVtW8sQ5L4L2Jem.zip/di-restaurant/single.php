<?php get_header(); ?>

<!-----##### post  section start ######------>
<div class="col-md-8 container-box-left">

	<?php
	while( have_posts() ) : the_post();
		get_template_part( 'template-parts/content', 'single' );
	endwhile;
	?>

	<?php
	// If comments are open or we have at least one comment, load up the comment template.
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}
	?>

	<?php
	the_post_navigation(
		array(
			'prev_text'	=> '&larr; %title',
			'next_text'	=> '%title &rarr;',
		)
	);
	?>

</div>
<!-----##### post section end ######------>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
