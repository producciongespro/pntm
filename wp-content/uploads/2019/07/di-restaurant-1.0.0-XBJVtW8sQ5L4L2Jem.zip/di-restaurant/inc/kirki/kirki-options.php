<?php
// Disable kirki telemetry
add_filter( 'kirki_telemetry', '__return_false' );

//set Kirki config
Kirki::add_config( 'di_restaurant_config', array(
	'capability'    => 'edit_theme_options',
	'option_type'   => 'theme_mod',
) );

//the main panel
Kirki::add_panel( 'di_restaurant_options', array(
    'title'       => esc_attr__( 'Di Restaurant Options', 'di-restaurant' ),
    'description' => esc_attr__( 'All options of Di Restaurant theme', 'di-restaurant' ),
) );

//typography
Kirki::add_section( 'typography_options', array(
	'title'          => esc_attr__( 'Typography Options', 'di-restaurant' ),
	'panel'          => 'di_restaurant_options',
	'capability'     => 'edit_theme_options',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'        => 'typography',
	'settings'    => 'body_typog',
	'label'       => esc_attr__( 'Body Typography', 'di-restaurant' ),
	'section'     => 'typography_options',
	'default'     => array(
		'font-family'    => 'Lora',
		'variant'        => 'regular',
		'font-size'      => '14px',
	),
	'output'      => array(
		array(
			'element' => 'body',
		),
	),
	'transport' => 'auto',
) );



//social profile
Kirki::add_section( 'social_options', array(
	'title'          => esc_attr__( 'Social Profile', 'di-restaurant' ),
	'panel'          => 'di_restaurant_options',
	'capability'     => 'edit_theme_options',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_facebook',
	'label'			=> esc_attr__( 'Facebook Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> 'http://facebook.com',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_twitter',
	'label'			=> esc_attr__( 'Twitter Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> 'http://twitter.com',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_youtube',
	'label'			=> esc_attr__( 'YouTube Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> 'http://youtube.com',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_vk',
	'label'			=> esc_attr__( 'VK Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_okru',
	'label'			=> esc_attr__( 'Ok.ru (odnoklassniki) Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_linkedin',
	'label'			=> esc_attr__( 'Linkedin Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_pinterest',
	'label'			=> esc_attr__( 'Pinterest Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_instagram',
	'label'			=> esc_attr__( 'Instagram Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_telegram',
	'label'			=> esc_attr__( 'Telegram Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_snapchat',
	'label'			=> esc_attr__( 'Snapchat Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_flickr',
	'label'			=> esc_attr__( 'Flickr Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_reddit',
	'label'			=> esc_attr__( 'Reddit Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_tumblr',
	'label'			=> esc_attr__( 'Tumblr Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_yelp',
	'label'			=> esc_attr__( 'Yelp Link', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_whatsappno',
	'label'			=> esc_attr__( 'WhatsApp Number', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );

Kirki::add_field( 'di_restaurant_config', array(
	'type'			=> 'text',
	'settings'		=> 'sprofile_link_skype',
	'label'			=> esc_attr__( 'Skype Id', 'di-restaurant' ),
	'description'	=> esc_attr__( 'Leave empty for disable', 'di-restaurant' ),
	'section'		=> 'social_options',
	'default'		=> '',
) );
//social profile END
