<?php
/**
 * Di Restaurant Actions Filter. This file is responsible mostly actions and filters.
 *
 * @package Di Restaurant
 */

/**
 * Class Di_Restaurant_Engine.
 */

class Di_Restaurant_Actions_Filter {

	/**
	 * Instance object.
	 *
	 * @var instance
	 */
	public static $instance;

	/**
	 * Get_instance method.
	 *
	 * @return instance instance of the class.
	 */
	public static function get_instance() {
		if ( empty( self::$instance ) ) {
			self::$instance = new self;
		}
		return self::$instance;
	}

	/**
	 * [__construct description]
	 */
	public function __construct() {
		add_action( 'di_restaurant_the_head', [ $this, 'the_head' ] );
		add_filter( 'get_calendar', [ $this, 'calendar_css_class' ] );
		add_filter( 'widget_tag_cloud_args', [ $this, 'tag_cloud_fontsize_fix' ] );
		add_filter( 'excerpt_more', [ $this, 'excerpt_more' ] );
		

		if( class_exists( 'WooCommerce' ) ) {
			add_filter( 'woocommerce_product_tag_cloud_widget_args', [ $this, 'woo_tag_cloud_fontsize_fix' ] );
		}
	}

	public function the_head() {
		?>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="profile" href="http://gmpg.org/xfn/11" />

		<?php if ( is_singular() && pings_open( get_queried_object() ) ) { ?>
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
		<?php } ?>
		
		<?php
	}

	public function calendar_css_class( $html ) {
		return str_replace( 'id="wp-calendar"', 'id="wp-calendar" class="table table-bordered"', $html );
	}

	public function tag_cloud_fontsize_fix( $args ) {
		$args['largest']  = 14;
		$args['smallest'] = 14;
		$args['unit']     = 'px';
		return $args;
	}

	public function excerpt_more( $more ) {
		global $post;
		return '<div class="readmore-section"><a href="' . esc_url( get_permalink( $post->ID ) ) . '"><input type="submit" name="submit" value="' . __( 'Continue reading', 'di-restaurant' ) . '&#8230;" class="readmore-btn" ></a></div>';

	}



	public function woo_tag_cloud_fontsize_fix( $args ) {
		$args['largest']  = 14;
		$args['smallest'] = 14;
		$args['unit']     = 'px';
		return $args;
	}

}
Di_Restaurant_Actions_Filter::get_instance();
