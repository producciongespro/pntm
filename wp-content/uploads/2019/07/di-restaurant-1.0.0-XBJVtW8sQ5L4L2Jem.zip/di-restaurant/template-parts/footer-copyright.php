<div class="container-fluid footer-copyright">
	<div class="container">
		<div class="row">
			<div class="col-md-4 footer-copyright-left">
				<p><a href="#">Terms of Use</a> - <a href="#">Privacy Policy</a></p> 
			</div>
			<div class="col-md-4 footer-copyright-center">
				<p>&copy; All rights reserved 2019</p>
			</div>
			<div class="col-md-4 footer-copyright-right">
				<p>WordPress</a> <span class="footer_span fa fa-thumbs-o-up"><a href="#"> Di Restaurant</a></span> Theme</p>
			</div>
		</div>
	</div>
</div>