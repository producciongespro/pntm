<div class="col-md-6 loop-single-post">
	<div id="post-<?php the_ID(); ?>" <?php post_class( 'post-inner' ); ?>>

		<?php
			Di_Restaurant_Methods::the_thumbnail();
		?>

		<div class="post-category">
			<?php
			the_category( ' ' );
			?>
		</div>

		<h3 class="the-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

		<div class="post-time"><?php the_date(); ?></div>

		<?php the_excerpt(); ?>

	</div>
</div>
