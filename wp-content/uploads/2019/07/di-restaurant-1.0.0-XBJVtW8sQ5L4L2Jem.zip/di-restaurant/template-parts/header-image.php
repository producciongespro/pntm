<div class="header-img-otr">
	<?php
	if( has_header_image() ) { ?>
	<div class="container-fluid header-img">
		<?php the_custom_header_markup(); ?>
	</div>
	<?php
	}
	?>
</div>

