<!--------------------------------loop section start--------------------->
<div id="post-<?php the_ID(); ?>" <?php post_class( 'post-inner' ); ?>>

	<?php
		Di_Restaurant_Methods::the_thumbnail();
	?>

	<div class="post-category">
		<?php
		the_category( ' ' );
		?>
	</div>

	<h3 class="the-title"><?php the_title(); ?></h3>

	<div class="post-time"><?php the_date(); ?></div>

	<?php
	the_content();
	?>

	<?php
	wp_link_pages(
		array(
		'before' => '<div class="page-links">' . __( 'Pages:', 'di-restaurant' ),
		'after'  => '</div>',
		)
	);
	?>

	<?php
	if( has_tag() ) { ?>
		<div class="widgets_sidebar widget_tag_cloud"><div class="tagcloud"><?php the_tags( '', ' ', '' ); ?></div></div>
	<?php
	}
	?>

</div>