<div class="container-fluid footer-widgets">
	<div class="container">
		<div class="row">

			<div class="col-md-3">

				<div class="widgets_footer widget_recent_entries">
					<h3 class="widgets_footer_title">Posts</h3>
						<ul>
							<li><a href="#">Hello world!</a><span class="post-date">June 18, 2019</span></li>
							<li><a href="#">Lorem Ipsum is simply dummy</a><span class="post-date">June 9, 2019</span></li>
							<li><a href="#">Various versions have evolved</a><span class="post-date">June 9, 2019</span></li>
							<li><a href="#">Entertainment passage of Lorem Ipsum</a><span class="post-date">June 9, 2019</span></li>
							<li><a href="#">Passages of Lorem Entertainment</a><span class="post-date">June 9, 2019</span></li>
						</ul>
				</div>

				<div class="widgets_footer widget_text">
					<h3 class="widgets_footer_title">Text Widget</h3>
						<div class="textwidget">
							<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>
						</div>
				</div>

			</div>

			<div class="col-md-3">

				<div class="widgets_footer widget_categories">
					<h3 class="widgets_footer_title">Categories</h3>
						<ul>
							<li><a href="#">Business News</a></li>
							<li><a href="#">Entertainment News</a></li>
							<li><a href="#">National News</a></li>
							<li><a href="#">Politics News</a></li>
							<li><a href="#">Sports News</a></li>
							<li><a href="#">Uncategorized</a></li>
						</ul>
				</div>

				<div class="widgets_footer widget_tag_cloud">
					<h3 class="widgets_footer_title">Tags</h3>
					<div class="tagcloud">
						<a href="#">Headlines</a>
						<a href="#">Latest</a>
						<a href="#">Left Slide</a>
						<a href="#">News</a>
						<a href="#">Right Grid</a>
						<a href="#">Top Slide</a>
					</div>
				</div>

				<div class="widgets_footer widget_categories">
					<h3 class="widgets_footer_title">Categories</h3>
					<form action="#" method="get">
						<select name="cat">
							<option value="-1">Select Category</option>
							<option value="2">Business News</option>
							<option value="3">Entertainment News</option>
							<option value="4">National News</option>
							<option value="5">Politics News</option>
							<option value="6">Sports News</option>
							<option value="1">Uncategorized</option>
						</select>
					</form>
				</div>

			</div>

			<div class="col-md-3">

				<div class="widgets_footer widget_pages">
					<h3 class="widgets_footer_title">Pages</h3>
						<ul>
							<li><a href="#">Blog</a></li>
							<li><a href="#">Home</a></li>
							<li><a href="#">Sample Page</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">Home</a></li>
							<li><a href="#">Sample Page</a></li>
						</ul>
				</div>

				<div class="widgets_footer widget_meta">
					<h3 class="widgets_footer_title">Meta</h3>
					<ul>
						<li><a href="#">Site Admin</a></li>			
						<li><a href="#">Log out</a></li>
						<li><a href="#">Entries RSS</a></li>
						<li><a href="#">Comments RSS</a></li>
						<li><a href="#">WordPress.org</a></li>
					</ul>
				</div>

			</div>


			<div class="col-md-3">

				<div class="widgets_footer widget_recent_comments">
					<h3 class="widgets_footer_title">Comments</h3>
					<ul>
						<li><span><a href="#">A WordPress Commenter</a></span><span> on </span> <span><a href="#">Hello world!</a></span></li>
						<li><span><a href="#">A Some Commenter</a></span> <span>on </span> <span><a href="#">New world!</a></span></li>
						<li><span><a href="#">A New User Commenter</a></span> <span>on</span> <span><a href="#">Old world!</a></span></li>
						<li><span><a href="#">A Premium Commenter</a></span> <span>on</span> <span><a href="#">First Post</a></span></li>
						<li><span><a href="#">A Some New Commenter</a></span><span> on</span> </span> <span><a href="#">Dummy Post</a></span></li>
						<li><span><a href="#">A Some New Commenter</a></span> <span>on</span> <span><a href="#">Dummy Post</a></span></li>
					</ul>
				</div>


				<div class="widgets_footer widget_archive">
					<h3 class="widgets_footer_title">Aechives</h3>
						<select name="archive-dropdown">
							<option value="#">Select Month</option>
							<option value="#"> June 2019 </option>
						</select>
				</div>

				<div class="widgets_footer widget_search">
					<h3 class="widgets_footer_title">Search website</h3>
					<form role="search" method="get" id="searchform" class="searchform" action="#">
						<div>
							<input type="text" value="" name="s" id="s">
							<input type="submit" id="searchsubmit" value="Search">
						</div>
					</form>
				</div>

			</div>

		</div>
	</div>
</div>