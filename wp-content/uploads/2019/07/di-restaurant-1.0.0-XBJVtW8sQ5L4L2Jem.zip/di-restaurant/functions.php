<?php

if( ! defined( 'ABSPATH' ) ) {
	die( "No Direct access" );
}

// Load init.php file.
require_once get_template_directory() . '/inc/init.php';

/*
* Do not edit any code of theme, use child theme instead
*/
