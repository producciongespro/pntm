<?php get_header(); ?>

<div class="col-md-8 container-box-left">
	<div class="row">

		<?php
		if( have_posts() ) {
			while( have_posts() ) : the_post();
				get_template_part( 'template-parts/content', 'loop' );
			endwhile;
			?>

			<div class="container posts_pagination">
				<?php
				the_posts_pagination( array(
					'prev_text' => __( '&laquo;', 'di-restaurant' ),
					'next_text' => __( '&raquo;', 'di-restaurant' ),
				) );
				?>
			</div>
			<?php

		} else {
			get_template_part( 'template-parts/content', 'none' );
		}
		?>
	</div>
</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
